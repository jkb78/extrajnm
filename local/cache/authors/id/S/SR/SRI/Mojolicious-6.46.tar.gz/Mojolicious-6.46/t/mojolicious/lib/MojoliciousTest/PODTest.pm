package MojoliciousTest::PODTest;

1;

=head1 One

PODTest

=head2 Two

  my $foo = 'bar';

=head3 Three

Hello

=head4 Four

World!

=cut
